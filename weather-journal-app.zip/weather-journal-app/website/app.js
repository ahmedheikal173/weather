const API='502718e605c321ec8e1f225b3de15ab4';
let d = new Date();
const newDate =d.getDate()+'/'+ (d.getMonth()+1)+'/'+ d.getFullYear();
const Generate=document.querySelector('#generate')

const whenClick = async () => {
    const Zcode=document.querySelector('#zip').value
    const feelings=document.querySelector('#feelings').value;

    const CZ=checkZipCode(Zcode);
    const CF=checkFeelings(feelings);

    const response =await fetch(`https://api.openweathermap.org/data/2.5/weather?zip=${Zcode}&appid=${API}&units=metric`);
    const data=await response.json();
    if(CZ&&CF)
    {checkExistence(data.name);}

    console.log(data.name);
    const temp =data.main.temp;
    const feelsLike=data.main.feels_like;
    const Feeelings=data.main.feelings;
    const getTitle=document.querySelector('.title');
    getTitle.textContent='';
    document.querySelector('#position').innerHTML=`<h2>Weather in ${data.name}</h2>`
    document.querySelector('#temp').innerHTML=`<h2>Temperature ${temp}°C</h2>`;
    document.querySelector('#content').innerHTML=`<h2>It seems ${document.querySelector('#feelings').value}</h2>`;
    document.querySelector('#date').innerHTML=`<h2>Date ${newDate}</h2>`;

    await fetch('/setData',{
        cerdentials:'same-origin',
        method:'POST',
        headers:{
            'Content-Type':'application/json'
        },
        body:JSON.stringify({
            data:newDate,
            temp:temp,
            content:content
        })
    });

    const serResp=await fetch('/tempData',{
        credentials:'same-origin'
    });
};

Generate.addEventListener('click',whenClick);
function checkZipCode(Zcode)
{
    let n=Zcode.toString();
    if(!Zcode)
    {
        alert('Please Enter The Zip Code');
        return false;
    }
    else
    {
        for(let i=0;i<n.length;i++)
        {
            if(n.charCodeAt(i)>57||n.charCodeAt(i)<48)
            {
                document.querySelector('#zip').value='';
                alert('Please Enter The Zip Code (Numbers Only)');
                //whenClick();
                debugger
                return false;
            }
        }
        debugger
        if(n.length!==5)
        {
            document.querySelector('#zip').value='';
            alert('Please Enter a Valid Zip Code');
            //whenClick();
            return false;
        }
    }
    return true;
}

function checkFeelings(feelings)
{
    let n=feelings.toString();
    for(let i=0;i<n.length;i++)
        {
            if(n.charCodeAt(i)<123&&n.charCodeAt(i)>64){}
            else
            {
                alert('Please Enter Your Feeling in letters only');
                document.querySelector('#feelings').value='';
                const regain=document.querySelector('textarea');
                debugger
                regain.placeholder='Enter your feelings here';
                
                whenClick();
                return false;
            }
        }
        return true;
}
function checkExistence(dato)
{
    if(!dato)
    {
        document.querySelector('#zip').value='';
        alert('Please Enter a Valid Zip Code');
        //whenClick();
        return ;
    }
}
